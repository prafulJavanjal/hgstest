var ourApp = angular.module('hgsApp', [
    "ngRoute",
    "ngResource",
    "pascalprecht.translate"
]);

ourApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
        when('/', {
            templateUrl: 'partials/index/index.html',
            controller: 'indexCtrl'
        })
        .when('/request', {
            templateUrl: 'partials/request-list/request-list.html',
            controller: 'requestCtrl'
        }).
        otherwise({
            redirectTo: '/'
        });
        // use the HTML5 History API
        // $locationProvider.html5Mode(true);
        // $locationProvider.html5Mode(true).hashPrefix('*');
    }
]);
 
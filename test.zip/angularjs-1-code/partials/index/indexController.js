ourApp.controller('indexCtrl', [ "$scope", "$resource", function($scope, $resource) {

    function init() {
        $scope.appName = "hgsApp";
        $scope.name = "";
        $scope.phone = "";
        $scope.email = "";
        $scope.city = "";
        $scope.language = "";
        $scope.message = "";
        $scope.terms = "";
        $scope.errorMsg = "";
        $scope.successMsg = "";
        $scope.dataValid = true;
    }

    init();

    $scope.addUser = function() {
        var controller = "backend/registerUser.php";
        
        // form submit code write here 
console.log($scope);

        // var emailResponse = $resource(controller + '?email=' + $scope.email);
        // emailResponse.get(function(data) {
        //     $scope.email = "";
        //     if (data.response) {
        //         $scope.successMsg = "SUBSCRIBE_OK";
        //     } else {
        //         $scope.successMsg = "";
        //         $scope.errorMsg = "SUBSCRIBE_ERR";
        //     }
        // });
    }

}]);